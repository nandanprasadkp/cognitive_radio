import os
import tensorflow as tf
from src.model import get_radio_cnn
from src.data_utils import load_and_split_pickle, load_mat_signal
from src.inference import analyze_spectrum

# --- SETTINGS ---
MODE = "PREDICT" # Change to "TRAIN" if you want to retrain
DATASET_PATH = "dataset/RML2016.10a_dict.pkl"
MAT_FILE_PATH = "dataset/test_signal.mat"
MODEL_SAVE_PATH = "cognitive_radio_model.keras"

def main():
    model = get_radio_cnn()

    if MODE == "TRAIN":
        print(" Loading Training Data...")
        xtrain, xtest, ytrain, ytest = load_and_split_pickle(DATASET_PATH)
        
        model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        model.fit(xtrain, ytrain, batch_size=1024, epochs=30, validation_data=(xtest, ytest))
        model.save(MODEL_SAVE_PATH)
        print(f"✅ Model saved to {MODEL_SAVE_PATH}")

    elif MODE == "PREDICT":
        if not os.path.exists(MODEL_SAVE_PATH):
            print("❌ No trained model found! Run in TRAIN mode first.")
            return
            
        model = tf.keras.models.load_model(MODEL_SAVE_PATH)
        print("📡 Analyzing Spectrum from .mat file...")
        signal = load_mat_signal(MAT_FILE_PATH)
        results = analyze_spectrum(model, signal)
        
        # Print Summary
        free_slots = [r for r in results if r['status'] == "FREE"]
        print(f"Done! Found {len(free_slots)} potential holes out of {len(results)} windows.")
        print(f"Availability: {(len(free_slots)/len(results))*100:.2f}%")

if __name__ == "__main__":
    main()